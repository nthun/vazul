# vazul 0.0.0.9000

## 2025-08-29 

* Package skeleton created with `usethis::create_package()`.
* Add Williams et. al dataset.
* Add MARP dataset.
